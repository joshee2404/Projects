<?php

require("vendor/autoload.php");

$sname= "localhost";
$unmae= "root";
$password = "root";

$db_name = "testdb";

$session = [];

$conn = new mysqli($sname, $unmae, $password, $db_name);
$mongoConn = new MongoDB\Client("mongodb://localhost:27017");
$mongoDb = $mongoConn->UserDetails;
$collection = $mongoDb->selectCollection("uDat");

if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}