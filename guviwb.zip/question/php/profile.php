<?php

include "db_conn.php";

$errors = [];
$data = [];

// Check connection
if($conn === false){
	die("ERROR: Could not connect. "
		. mysqli_connect_error());
}

if (!empty($_POST['dob']) && !empty($_POST['age']) && !empty($_POST['contact'])) {
    $userToChange = ['name'=>$_POST['user'], 'email'=>$_POST['email']];
    $toChange = ['age'=>$_POST['age'], 'dob'=>$_POST['dob'], 'contact'=>$_POST['contact']];
    $collection->updateOne($userToChange, ['$set'=>$toChange]);
    $data['success'] = true;
    $data['message'] = 'Successfully changeed your info';
}

echo json_encode($data);