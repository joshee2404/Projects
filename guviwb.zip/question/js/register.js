$(document).ready(function () {
    $("form").submit(function (event) {
      $(".form-group").removeClass("has-error");
      $(".help-block").remove();
      var formData = {
        uname: $("#name").val(),
        email: $("#email").val(),
        pass: $("#pass").val(),
        dob: $('#dob').val(),
        age: $('#age').val(),
        contact: $('#num').val()
      };
  
      $.ajax({
        type: "POST",
        url: "../question/php/register.php",
        data: formData,
        dataType: "json",
        encode: true,
      }).done(function (data) {
        console.log(data);
        sessionStorage.setItem("session", JSON.stringify(data['session']));
        if (!data.success) {
          if (data.errors.name) {
            $("#name-group").addClass("has-error");
            $("#name-group").append(
              '<div class="help-block">' + data.errors.name + "</div>"
            );
          }
  
          if (data.errors.email) {
            $("#email-group").addClass("has-error");
            $("#email-group").append(
              '<div class="help-block">' + data.errors.email + "</div>"
            );
          }
  
          if (data.errors.pass) {
            $("#pass-group").addClass("has-error");
            $("#pass-group").append(
              '<div class="help-block">' + data.errors.pass + "</div>"
            );
          }
        } else {
          $("form").html(
            '<div class="alert alert-success">' + data.message + '<a href="./login.html">   Login</a>'
          );
        }
      })
  
      event.preventDefault();
    });
  });